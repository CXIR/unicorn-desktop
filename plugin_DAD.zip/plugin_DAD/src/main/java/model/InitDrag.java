package model;

import PluginManager.IPlugin;
import controller.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.control.Button;

import java.io.IOException;

/**
 * Created by Micka on 07/07/2017.
 */
public class InitDrag implements IPlugin {
    private String name;

    public String getName(){
        return name;
    }

    /**
     * Create a button who will appear in the user menu
     * The button will connect to DragAndDrop class
     */
    public void init() {
        this.name = "controller/DragAndDrop";
        new Loader("/view/User.fxml", "GESTION DES UTILISATEURS");
        Button button = new Button("Ajouter des utilisateurs");

        button.setOnAction(event -> {
            try {
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getClassLoader().getResource("view/dragAndDrop.fxml"));
                loader.setController(new DragAndDrop());
                Group group = (Group) loader.load();
                Menu.menu.fillPane(group, "AJOUTER DES UTILISATEURS");

            } catch (IOException e) {
                e.printStackTrace();
                throw new IllegalStateException("Erreur fichier FXML");
            }
        });

        User_menu.user_menu.addButton(button);
        new Loader("/view/Home.fxml", "PARTAGE TA CAISSE");
    }
}
