package model;

import PluginManager.IPlugin;
import controller.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.control.Button;

import java.io.IOException;

/**
 * Created by Micka on 07/07/2017.
 */
public class InitDrag implements IPlugin {
    private String name;

    public String getName(){
        return name;
    }

    public void init() {
        this.name = "ffdf";
        if (User_menu.user_menu == null){
            new Loader("/view/User.fxml", "GESTION DES UTILISATEURS");
            Button button = new Button("Ajouter des utilisateurs");
            User_menu.user_menu.addButton(button);
        }
        else{
            try {
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getClassLoader().getResource("view/dragAndDrop.fxml"));
                loader.setController(new DragAndDrop());
                Group group = (Group) loader.load();
                Menu.menu.fillPane(group, "AJOUTER DES UTILISATEURS");

            } catch (IOException e) {
                e.printStackTrace();
                throw new IllegalStateException("Erreur fichier FXML");
            }
        }

    }
}
