package controller;

//import controller.Loader;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import model.Main;
import model.ReadFile;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Created by mickael.afonso on 07/04/2017.
 */
public class DragAndDrop implements Initializable {
    private ArrayList<File> files = new ArrayList<File>();

    @FXML
    private Label name;

    @FXML
    private Button search;

    @FXML
    private Rectangle drop;

    @FXML
    private StackPane stack;

    @FXML
    private Button valid;

    @FXML
    private Button cancel;

    public String extension(File file){
        return file.getName().substring(file.getName().indexOf('.') + 1,file.getName().length());
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        search.setOnAction(event -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Sélectionner le fichier");
            File file = fileChooser.showOpenDialog(Main.primaryStage);
            String ext = extension(file);
            if(file != null && (ext.equals("txt") || ext.equals("csv"))){
                files.add(file);
                name.setText(name.getText() + ", " + file.getName());
            }
        });

        stack.setOnDragOver(event -> {
            Dragboard db = event.getDragboard();
            if(db.hasFiles()){
                event.acceptTransferModes(TransferMode.LINK);
            }
            event.consume();
        });

        stack.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();
            if(db.hasFiles()){
                name.setText("");
                files.clear();
                for (File file : db.getFiles()) {
                    String ext = extension(file);
                    if(ext.equals("txt") || ext.equals("csv")){
                        files.add(file);
                        name.setText(name.getText() + ", " + file.getName());
                    }
                    else{
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Erreur");
                        alert.setContentText("Le type de fichier est invalide.");
                        alert.showAndWait();
                    }
                }
            }
            event.consume();
        });

        valid.setOnAction(event -> {
            if(files != null){
                for(File file : files){
                    ReadFile read = new ReadFile(file, extension(file));
                    read.read();
                }
            }
            change();
        });

        cancel.setOnAction(event -> {
            change();
        });
    }

    public void change(){
        User_menu user_menu = User_menu.user_menu;
        Loader loader = new Loader("/view/User.fxml","GESTION DES UTILISATEURS");
        User_menu user_m = loader.getLoader().getController();
        if (user_menu.getButtons().size() > 0){
            for (Button button : user_menu.getButtons()){
                user_m.addButton(button);
            }
        }
    }
}
